function demoExternalAlert(){
    alert("External Alert.");
}
function demoExternalConfirm(){
    if(confirm("Are you sure..??")){
        alert("Yess");
    }
    else{
        alert("Nooo");
    }
}
function demoExternalPrompt(){
    var fName=prompt("Enter Firstname");
    var lName=prompt("Enter Lastnam ");
    alert(fName+" "+lName);
}